<div class="edgtf-vss-ms-section" <?php echo playerx_edge_get_inline_attrs($content_data); ?> <?php playerx_edge_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>