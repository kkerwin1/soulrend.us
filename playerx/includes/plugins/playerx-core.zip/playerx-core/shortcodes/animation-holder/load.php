<?php

include_once PLAYERX_CORE_SHORTCODES_PATH . '/animation-holder/functions.php';
include_once PLAYERX_CORE_SHORTCODES_PATH . '/animation-holder/animation-holder.php';