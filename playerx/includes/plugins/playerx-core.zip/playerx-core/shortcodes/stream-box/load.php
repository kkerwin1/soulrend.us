<?php

include_once PLAYERX_CORE_SHORTCODES_PATH . '/stream-box/functions.php';
include_once PLAYERX_CORE_SHORTCODES_PATH . '/stream-box/stream-box.php';