<div class="edgtf-clients-grid-holder edgtf-grid-list edgtf-disable-bottom-space <?php echo esc_attr( $holder_classes ); ?>">
	<div class="edgtf-cg-inner edgtf-outer-space">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>