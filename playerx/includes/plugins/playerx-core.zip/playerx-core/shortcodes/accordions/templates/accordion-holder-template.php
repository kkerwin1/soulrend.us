<div class="edgtf-accordion-holder <?php echo esc_attr($holder_classes); ?> clearfix">
	<?php echo do_shortcode($content); ?>
</div>