<?php

namespace PlayerxCore\Lib;

/**
 * interface PostTypeInterface
 * @package PlayerxCore\Lib;
 */
interface PostTypeInterface {
	/**
	 * @return string
	 */
	public function getBase();
	
	/**
	 * Registers custom post type with WordPress
	 */
	public function register();
}