<?php

get_header();

playerx_edge_get_title();

do_action('playerx_edge_action_before_main_content');

playerx_core_get_single_portfolio();

get_footer();